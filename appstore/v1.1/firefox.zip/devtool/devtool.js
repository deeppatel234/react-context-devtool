chrome.devtools.panels.create(
  "React Context",
  "logo.png",
  "../devpanel/devpanel.html",
  function() {}
);
