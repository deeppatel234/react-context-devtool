# Privacy Policy

## Personal data
react-context-devtool had never collected and will never collect any personal data, browsing history etc. react-context-devtool traverse react fiber tree to get context and useReducer nodes for debugging data if the user has attached handler in the code. it does not send any data to any server. it processes data on-device.
In future, react-context-devtool may collect browser version, platform name. This information is needed for a decision on implementing new features, removing unused features.

## Third party services
react-context-devtool uses Chrome (Chromium) and browser's Web Storage API (localStorage) for storing user's settings.
