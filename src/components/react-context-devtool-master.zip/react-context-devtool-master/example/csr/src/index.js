import React from "react";
import ReactDOM from "react-dom";
import App from "./App";

ReactDOM.render(<App />, document.getElementById("root"));

window.__REACT_CONTEXT_DEVTOOL_GLOBAL_HOOK.helpers.loadHookHelper().then(() => {
    window.__REACT_CONTEXT_DEVTOOL_GLOBAL_HOOK.debugFiber(document.getElementById('root'))
});
