chrome.devtools.panels.create(
  "React Context",
  "",
  "/devtool/devpanel.html",
  function() {}
);
