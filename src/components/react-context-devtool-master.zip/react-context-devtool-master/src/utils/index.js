export const isObject = (obj) => {
  return obj === Object(obj);
};
